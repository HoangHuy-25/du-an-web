# NHẬT KÝ PROMPT
- Họ tên: [Nguyen Hoang Huy]
- MSSV: [25810125]
- Công cụ AI: [ChatGPT / Gemini / Claude / Copilot]
 
## Lần 1 - Ngày 1
- Mục đích: Khung ngữ cảnh cố định
- Prompt đã dùng: PROMPT MẪU 0
- Kết quả: AI "Đã hiểu"
- Vấn đề gặp phải: Không.
- Điều tôi học được: Cách hoạt động AI
## Lần 2 - Ngày 1
- Mục đích: AI phỏng vấn để viết bản đặc tả
- Prompt đã dùng: PROMPT MẪU 1
- Kết quả: du_an_web/
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│       ├── banner.jpg
│       ├── banh-ngot/
│       └── do-uong/
├── views/
│   ├── index.ejs
│   ├── menu.ejs
│   ├── product-detail.ejs
│   └── about.ejs
├── app.js
└── package.json
- Vấn đề gặp phải: Không.
- Điều tôi học được: Xây dựng bản đặc tả
## Lần 3 - Ngày 1
- Mục đích: Phác thảo bố cục bằng ký tự
- Prompt đã dùng: PROMPT MẪU 2
- Kết quả:
+----------------------------------------------------------+
|                    HEADER / ĐẦU TRANG                    |
|                                                          |
|  LOGO + TÊN TIỆM       MENU       MENU SP       LIÊN HỆ   |
+----------------------------------------------------------+
|                                                          |
|                   BANNER / ẢNH BÌA                       |
|                                                          |
|              TIỆM BÁNH NGỌT & QUÁN CÀ PHÊ                |
|          Bánh ngon mỗi ngày - Cà phê đậm vị              |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|                  DANH MỤC SẢN PHẨM                       |
|                                                          |
|  +----------------+ +----------------+ +----------------+ |
|  |                | |                | |                | |
|  |  ẢNH BÁNH NGỌT | |   ẢNH CÀ PHÊ   | |  ẢNH ĐỒ UỐNG  | |
|  |                | |                | |                | |
|  |   Bánh ngọt    | |     Cà phê     | |  Đồ uống khác | |
|  +----------------+ +----------------+ +----------------+ |
|                                                          |
+----------------------------------------------------------+
|                                                          |
|                 SẢN PHẨM NỔI BẬT                         |
|                                                          |
|  +----------------+ +----------------+ +----------------+ |
|  |   ẢNH SP 1     | |   ẢNH SP 2     | |   ẢNH SP 3     | |
|  |                | |                | |                | |
|  | Tên sản phẩm   | | Tên sản phẩm   | | Tên sản phẩm   | |
|  | Giá sản phẩm   | | Giá sản phẩm   | | Giá sản phẩm   | |
|  +----------------+ +----------------+ +----------------+ |
|                                                          |
|  +----------------+ +----------------+ +----------------+ |
|  |   ẢNH SP 4     | |   ẢNH SP 5     | |   ẢNH SP 6     | |
|  |                | |                | |                | |
|  | Tên sản phẩm   | | Tên sản phẩm   | | Tên sản phẩm   | |
|  | Giá sản phẩm   | | Giá sản phẩm   | | Giá sản phẩm   | |
|  +----------------+ +----------------+ +----------------+ |
|                                                          |
+----------------------------------------------------------+
|                    THÔNG TIN CỬA HÀNG                    |
|                                                          |
|  Địa chỉ        | Số điện thoại     | Giờ mở cửa         |
|  Bản đồ         | Thông tin liên hệ |                   |
|                                                          |
+----------------------------------------------------------+
|                       FOOTER                             |
|              Tên tiệm - Thông tin bản quyền              |
+----------------------------------------------------------+
- Vấn đề gặp phải: Không.
- Điều tôi học được: Cách phác thảo bố cục.
## Lần 4 - Ngày 1
- Mục đích: Dựng trang chủ từ bản đặc tả
- Prompt đã dùng: PROMPT MẪU 3
- Kết quả: tạo được file index.html và style.css
- Vấn đề gặp phải: Không.
- Điều tôi học được: Dựng thành công trang chủ.